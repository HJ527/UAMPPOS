import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CardImageComponent } from '@components/organism';
import {
  IconComponent,
  ButtonComponent,
  ChipComponent,
} from '@components/atom';
import { CurrencyPipe } from '@angular/common';
import { ButtonStyle } from '@theme/enums';
import { HeaderComponent, SearchBarComponent } from '@components/molecule';

@Component({
  selector: 'app-checkout',
  standalone: true,
  imports: [
    CardImageComponent,
    IconComponent,
    CurrencyPipe,
    ButtonComponent,
    HeaderComponent,
    SearchBarComponent,
    ChipComponent,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  templateUrl: './checkout.component.html',
  styleUrl: './checkout.component.scss',
})
export class CheckoutComponent {
  btnStyle = ButtonStyle;

  configIconOrder = {
    name: 'bill',
    direction: 'top',
    height: '2rem',
    width: '2rem',
  };

  categorySelected(category: string) {
    console.log(category);
  }
}
